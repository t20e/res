#include<iostream>
#include <cmath>

using std::cout;

void swap(std::string &x, std::string &y);

int main(){

    
    cout << pow(2, 3);

    return 0;
}